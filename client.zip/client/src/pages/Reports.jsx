import { useEffect, useState } from 'react';
import * as XLSX from 'xlsx';
import * as reportsApi from '../api/reports.js';
import { todayStr, addDays } from '../utils/dateUtils.js';

export default function Reports() {
  const [anchorDate, setAnchorDate] = useState(todayStr());
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const [nsaRows, setNsaRows] = useState(null);
  const [nsaLoading, setNsaLoading] = useState(true);
  const [nsaStart, setNsaStart] = useState('');
  const [nsaEnd, setNsaEnd] = useState('');

  async function load(date) {
    setLoading(true);
    setData(await reportsApi.getWeeklySummary(date));
    setLoading(false);
  }

  async function loadNsa(start, end) {
    setNsaLoading(true);
    setNsaRows(await reportsApi.getNsaReport({ start, end }));
    setNsaLoading(false);
  }

  useEffect(() => {
    load(anchorDate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [anchorDate]);

  useEffect(() => {
    loadNsa(nsaStart, nsaEnd);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nsaStart, nsaEnd]);

  function exportToExcel() {
    const sheetData = nsaRows.map((r) => ({
      'Email ID': r.email_id,
      'Name': r.name,
      'Project Name': r.project_name,
      'Type of Allowance': r.type_of_allowance,
      'Total Amount (INR)': r.total_amount,
      'Date Worked': r.date_worked,
    }));
    const sheet = XLSX.utils.json_to_sheet(sheetData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet, 'NSA');
    XLSX.writeFile(wb, 'NSA_Report.xlsx');
  }

  return (
    <div className="flex flex-col gap-6">
      <h2 className="text-xl font-bold text-gray-900 m-0">Weekly Summary</h2>

      {/* Week navigation */}
      <div className="bg-white rounded-2xl shadow-sm p-6">
        <div className="flex items-center gap-3 flex-wrap mb-6">
          <button
            onClick={() => setAnchorDate((d) => addDays(d, -7))}
            className="px-4 py-1.5 rounded-full text-sm font-medium border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
          >
            ← Previous week
          </button>
          <span className="text-sm text-gray-500 font-medium">
            {data ? `${data.week_start} – ${data.week_end}` : ''}
          </span>
          <button
            onClick={() => setAnchorDate((d) => addDays(d, 7))}
            className="px-4 py-1.5 rounded-full text-sm font-medium border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
          >
            Next week →
          </button>
          <button
            onClick={() => setAnchorDate(todayStr())}
            className="px-4 py-1.5 rounded-full text-sm font-medium bg-violet-600 text-white hover:bg-violet-700 transition-colors"
          >
            This week
          </button>
        </div>

        {loading || !data ? (
          <p className="text-gray-400 text-sm">Loading…</p>
        ) : data.summary.length === 0 ? (
          <p className="text-gray-400 italic text-sm">No employees to report on yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="soft-table">
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Department</th>
                  <th>Hours worked</th>
                  <th>Leave days</th>
                  <th>Leave breakdown</th>
                </tr>
              </thead>
              <tbody>
                {data.summary.map((row) => (
                  <tr key={row.employee_id}>
                    <td className="font-medium text-gray-800">{row.name}</td>
                    <td className="text-gray-500">{row.department}</td>
                    <td className="text-gray-800">{row.hours_worked}</td>
                    <td className="text-gray-800">{row.leave_days}</td>
                    <td className="text-gray-500">
                      {Object.entries(row.leave_breakdown).length === 0
                        ? '—'
                        : Object.entries(row.leave_breakdown)
                            .map(([type, days]) => `${type}: ${days}`)
                            .join(', ')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* NSA section */}
      <h2 className="text-xl font-bold text-gray-900 m-0">Night Shift Allowance (NSA)</h2>
      <div className="bg-white rounded-2xl shadow-sm p-6">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
          <p className="text-sm text-gray-500 m-0">
            Shifts starting at or after 5:30 PM — ₹900 per qualifying day.
          </p>
          {nsaRows && nsaRows.length > 0 && (
            <button
              onClick={exportToExcel}
              className="px-4 py-1.5 rounded-full text-sm font-medium bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
            >
              Export to Excel
            </button>
          )}
        </div>
        <div className="flex items-center gap-3 flex-wrap mb-6">
          <span className="text-sm text-gray-500">From</span>
          <input
            type="date"
            value={nsaStart}
            onChange={(e) => setNsaStart(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 text-gray-600"
          />
          <span className="text-sm text-gray-500">To</span>
          <input
            type="date"
            value={nsaEnd}
            onChange={(e) => setNsaEnd(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 text-gray-600"
          />
          {(nsaStart || nsaEnd) && (
            <button
              onClick={() => { setNsaStart(''); setNsaEnd(''); }}
              className="text-sm text-gray-400 hover:text-gray-600 transition-colors"
            >
              Clear
            </button>
          )}
        </div>

        {nsaLoading ? (
          <p className="text-gray-400 text-sm">Loading…</p>
        ) : !nsaRows || nsaRows.length === 0 ? (
          <p className="text-gray-400 italic text-sm">
            No qualifying night shifts found. Make sure employees have Email ID and Project Name set.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="soft-table">
              <thead>
                <tr>
                  <th>Email ID</th>
                  <th>Name</th>
                  <th>Project Name</th>
                  <th>Type of Allowance</th>
                  <th>Total Amount (INR)</th>
                  <th>Date Worked</th>
                </tr>
              </thead>
              <tbody>
                {nsaRows.map((row, i) => (
                  <tr key={i}>
                    <td className="text-gray-600">{row.email_id}</td>
                    <td className="font-medium text-gray-800">{row.name}</td>
                    <td className="text-gray-600">{row.project_name}</td>
                    <td className="text-gray-800">{row.type_of_allowance}</td>
                    <td className="text-gray-800">₹{row.total_amount}</td>
                    <td className="text-gray-600">{row.date_worked}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
