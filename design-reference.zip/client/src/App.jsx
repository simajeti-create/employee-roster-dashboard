import { NavLink, Route, Routes } from 'react-router-dom';
import Dashboard from './pages/Dashboard.jsx';
import Employees from './pages/Employees.jsx';
import Leaves from './pages/Leaves.jsx';
import Reports from './pages/Reports.jsx';

const NAV = [
  { to: '/',          end: true,  icon: '⊞', label: 'Dashboard' },
  { to: '/employees',             icon: '👥', label: 'Employees' },
  { to: '/leaves',                icon: '📅', label: 'Leaves' },
  { to: '/reports',               icon: '📊', label: 'Reports' },
];

export default function App() {
  return (
    <div className="flex min-h-screen" style={{ background: '#f5f4f8' }}>
      {/* ── Sidebar ─────────────────────────────────────────── */}
      <aside
        className="flex flex-col w-56 shrink-0 py-6"
        style={{ background: '#12101e' }}
      >
        {/* Brand */}
        <div className="px-5 mb-8">
          <span className="text-white font-bold text-lg tracking-tight">
            Employee Roster
          </span>
        </div>

        {/* Nav links */}
        <nav className="flex flex-col gap-1 px-3 flex-1">
          {NAV.map(({ to, end, icon, label }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                [
                  'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-violet-600 text-white'
                    : 'text-gray-400 hover:bg-white/10 hover:text-white',
                ].join(' ')
              }
            >
              <span className="text-base leading-none">{icon}</span>
              {label}
            </NavLink>
          ))}
        </nav>
      </aside>

      {/* ── Main content ────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-14 bg-white border-b border-gray-100 flex items-center px-6 shadow-sm shrink-0">
          <span className="text-gray-400 text-sm">Welcome back</span>
        </header>

        <main className="flex-1 p-6 overflow-auto">
          <Routes>
            <Route path="/"          element={<Dashboard />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/leaves"    element={<Leaves />} />
            <Route path="/reports"   element={<Reports />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
