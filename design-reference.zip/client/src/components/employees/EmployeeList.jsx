const AVATAR_COLORS = [
  '#7c3aed', '#2563eb', '#059669', '#d97706',
  '#dc2626', '#0891b2', '#9333ea', '#b45309',
];

function initials(name) {
  return name
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();
}

function avatarColor(name) {
  let hash = 0;
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) & 0xffff;
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

export default function EmployeeList({ employees, onEdit, onDelete }) {
  if (employees.length === 0) {
    return (
      <p className="text-gray-400 italic text-sm">
        No employees yet. Add your first one above.
      </p>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="soft-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Department</th>
            <th>Role</th>
            <th>Default shift</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id}>
              <td>
                <div className="flex items-center gap-3">
                  <span
                    className="avatar"
                    style={{ background: avatarColor(emp.name) }}
                  >
                    {initials(emp.name)}
                  </span>
                  <span className="text-sm font-medium text-gray-800">{emp.name}</span>
                </div>
              </td>
              <td className="text-gray-500 text-sm">{emp.department}</td>
              <td className="text-gray-500 text-sm">{emp.role}</td>
              <td className="text-gray-500 text-sm">
                {emp.default_shift_start && emp.default_shift_end
                  ? `${emp.default_shift_start}–${emp.default_shift_end}`
                  : '—'}
              </td>
              <td>
                <span
                  className={`badge ${emp.employment_status === 'active' ? 'approved' : 'inactive'}`}
                >
                  {emp.employment_status}
                </span>
              </td>
              <td>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onEdit(emp)}
                    className="px-3 py-1 rounded-lg text-xs font-medium border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => onDelete(emp)}
                    className="px-3 py-1 rounded-lg text-xs font-medium border border-red-100 text-red-500 hover:bg-red-50 transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
