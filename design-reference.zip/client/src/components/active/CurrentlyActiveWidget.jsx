const STATUS_CLASS = {
  'On Shift': 'on-shift',
  'On Break': 'on-break',
  'On Leave': 'on-leave',
  Off: 'off',
};

const AVATAR_COLORS = [
  '#7c3aed', '#2563eb', '#059669', '#d97706',
  '#dc2626', '#7c3aed', '#0891b2', '#9333ea',
];

function initials(name) {
  return name
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();
}

function avatarColor(name) {
  let hash = 0;
  for (const ch of name) hash = (hash * 31 + ch.charCodeAt(0)) & 0xffff;
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

export default function CurrentlyActiveWidget({ entries }) {
  if (entries.length === 0) {
    return (
      <p className="text-gray-400 italic text-sm py-2">
        No employees match the current filters.
      </p>
    );
  }

  return (
    <ul className="divide-y divide-gray-50 -mx-1">
      {entries.map(({ employee, status }) => (
        <li key={employee.id} className="flex items-center gap-3 px-1 py-2.5">
          <span
            className="avatar"
            style={{ background: avatarColor(employee.name) }}
          >
            {initials(employee.name)}
          </span>
          <span className="flex-1 min-w-0">
            <span className="block text-sm font-medium text-gray-800 truncate">
              {employee.name}
            </span>
            <span className="block text-xs text-gray-400">{employee.department}</span>
          </span>
          <span className={`badge ${STATUS_CLASS[status]}`}>{status}</span>
        </li>
      ))}
    </ul>
  );
}
