export default function LeaveList({ leaves, employeesById, onEdit, onDelete }) {
  if (leaves.length === 0) {
    return <p className="empty-state">No leave records match the current filters.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="soft-table">
        <thead>
          <tr>
            <th>Employee</th>
            <th>Type</th>
            <th>Dates</th>
            <th>Status</th>
            <th>Reason</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {leaves.map((leave) => (
            <tr key={leave.id}>
              <td className="font-medium text-gray-800 text-sm">
                {employeesById.get(leave.employee_id)?.name ?? `#${leave.employee_id}`}
              </td>
              <td className="text-gray-500 text-sm">{leave.leave_type}</td>
              <td className="text-gray-500 text-sm">
                {leave.start_date === leave.end_date
                  ? leave.start_date
                  : `${leave.start_date} → ${leave.end_date}`}
              </td>
              <td>
                <span className={`badge ${leave.status}`}>{leave.status}</span>
              </td>
              <td className="text-gray-500 text-sm">{leave.reason || '—'}</td>
              <td>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onEdit(leave)}
                    className="px-3 py-1 rounded-lg text-xs font-medium border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
                  >
                    Edit
                  </button>
                  <button
                    className="px-3 py-1 rounded-lg text-xs font-medium border border-red-100 text-red-500 hover:bg-red-50 transition-colors"
                    onClick={() => onDelete(leave)}
                  >
                    Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
