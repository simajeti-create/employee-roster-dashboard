import { useState } from 'react';
import Modal from '../common/Modal.jsx';
import * as shiftsApi from '../../api/shifts.js';
import * as breaksApi from '../../api/breaks.js';

function timeFromDateTime(dt) {
  return dt ? dt.slice(11, 16) : '';
}

export default function ShiftEditor({ employee, date, shift, breaks, leave, onClose, onSaved }) {
  const [startTime, setStartTime] = useState(timeFromDateTime(shift?.start_time) || employee.default_shift_start || '');
  const [endTime, setEndTime] = useState(timeFromDateTime(shift?.end_time) || employee.default_shift_end || '');
  const [notes, setNotes] = useState(shift?.notes || '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [breakStart, setBreakStart] = useState('');
  const [breakEnd, setBreakEnd] = useState('');

  async function notifySaved() {
    await onSaved();
  }

  async function handleSaveShift(e) {
    e.preventDefault();
    if (!startTime || !endTime) {
      setError('Start and end time are required.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      const payload = {
        employee_id: employee.id,
        work_date: date,
        start_time: `${date} ${startTime}`,
        end_time: `${date} ${endTime}`,
        notes: notes || null,
      };
      if (shift) {
        await shiftsApi.updateShift(shift.id, payload);
      } else {
        await shiftsApi.createShift(payload);
      }
      await notifySaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteShift() {
    if (!confirm('Delete this shift? Its breaks will be removed too.')) return;
    await shiftsApi.deleteShift(shift.id);
    await notifySaved();
  }

  async function handleAddBreak(e) {
    e.preventDefault();
    if (!breakStart) return;
    await breaksApi.createBreak({
      shift_id: shift.id,
      start_time: `${date} ${breakStart}`,
      end_time: breakEnd ? `${date} ${breakEnd}` : null,
    });
    setBreakStart('');
    setBreakEnd('');
    await notifySaved();
  }

  async function handleDeleteBreak(id) {
    await breaksApi.deleteBreak(id);
    await notifySaved();
  }

  async function handleEndBreakNow(id) {
    const now = new Date();
    const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    await breaksApi.updateBreak(id, { end_time: `${date} ${hhmm}` });
    await notifySaved();
  }

  return (
    <Modal title={`${employee.name} — ${date}`} onClose={onClose}>
      {leave && (
        <p className="leave-tag">
          On {leave.leave_type} leave ({leave.status}) covering this date.
        </p>
      )}

      <form onSubmit={handleSaveShift}>
        <div className="form-row">
          <div className="field">
            <label>Shift start</label>
            <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
          </div>
          <div className="field">
            <label>Shift end</label>
            <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label>Notes (optional)</label>
          <input value={notes} onChange={(e) => setNotes(e.target.value)} />
        </div>
        {error && <p className="error-text">{error}</p>}
        <div className="form-actions">
          <button type="submit" className="primary" disabled={saving}>
            {saving ? 'Saving…' : shift ? 'Update shift' : 'Create shift'}
          </button>
          {shift && (
            <button type="button" className="danger" onClick={handleDeleteShift}>
              Delete shift
            </button>
          )}
        </div>
      </form>

      {shift && (
        <div style={{ marginTop: 20 }}>
          <h2>Breaks</h2>
          {breaks.length === 0 && <p className="empty-state">No breaks logged.</p>}
          {breaks.map((b) => (
            <div className="break-row" key={b.id}>
              <span>
                {timeFromDateTime(b.start_time)} – {b.end_time ? timeFromDateTime(b.end_time) : 'ongoing'}
              </span>
              {!b.end_time && <button onClick={() => handleEndBreakNow(b.id)}>End now</button>}
              <button className="danger" onClick={() => handleDeleteBreak(b.id)}>
                Delete
              </button>
            </div>
          ))}
          <form onSubmit={handleAddBreak} className="form-row" style={{ marginTop: 8 }}>
            <div className="field">
              <label>Break start</label>
              <input type="time" value={breakStart} onChange={(e) => setBreakStart(e.target.value)} />
            </div>
            <div className="field">
              <label>Break end (optional)</label>
              <input type="time" value={breakEnd} onChange={(e) => setBreakEnd(e.target.value)} />
            </div>
            <div className="form-actions" style={{ alignSelf: 'flex-end' }}>
              <button type="submit">Add break</button>
            </div>
          </form>
        </div>
      )}
    </Modal>
  );
}
