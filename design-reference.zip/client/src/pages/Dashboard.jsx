import { useEffect, useMemo, useState } from 'react';
import DepartmentFilter from '../components/filters/DepartmentFilter.jsx';
import StatusFilter from '../components/filters/StatusFilter.jsx';
import CurrentlyActiveWidget from '../components/active/CurrentlyActiveWidget.jsx';
import RosterGrid from '../components/roster/RosterGrid.jsx';
import * as employeesApi from '../api/employees.js';
import * as activeApi from '../api/active.js';
import { startOfWeek, todayStr } from '../utils/dateUtils.js';

const ACTIVE_REFRESH_MS = 60000;

const STAT_CARDS = [
  {
    key: 'On Shift',
    label: 'On Shift',
    icon: '💼',
    iconBg: '#ede9fe',
    iconColor: '#7c3aed',
  },
  {
    key: 'On Break',
    label: 'On Break',
    icon: '☕',
    iconBg: '#fef3c7',
    iconColor: '#d97706',
  },
  {
    key: 'On Leave',
    label: 'On Leave',
    icon: '🏖️',
    iconBg: '#fee2e2',
    iconColor: '#dc2626',
  },
  {
    key: 'Off',
    label: 'Off Today',
    icon: '🌙',
    iconBg: '#f3f4f6',
    iconColor: '#6b7280',
  },
];

export default function Dashboard() {
  const [employees, setEmployees] = useState([]);
  const [activeEntries, setActiveEntries] = useState([]);
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [weekStart, setWeekStart] = useState(startOfWeek(todayStr()));
  const [loading, setLoading] = useState(true);

  async function loadEmployees() {
    setEmployees(await employeesApi.listEmployees({ employment_status: 'active' }));
  }

  async function loadActive() {
    setActiveEntries(await activeApi.getCurrentlyActive());
  }

  useEffect(() => {
    (async () => {
      setLoading(true);
      await Promise.all([loadEmployees(), loadActive()]);
      setLoading(false);
    })();
    const interval = setInterval(loadActive, ACTIVE_REFRESH_MS);
    return () => clearInterval(interval);
  }, []);

  const departments = useMemo(
    () => [...new Set(employees.map((e) => e.department))].sort(),
    [employees]
  );

  const statusByEmployeeId = useMemo(
    () => new Map(activeEntries.map((e) => [e.employee.id, e.status])),
    [activeEntries]
  );

  const filteredEmployees = useMemo(
    () =>
      employees.filter((emp) => {
        if (departmentFilter && emp.department !== departmentFilter) return false;
        if (statusFilter && statusByEmployeeId.get(emp.id) !== statusFilter) return false;
        return true;
      }),
    [employees, departmentFilter, statusFilter, statusByEmployeeId]
  );

  const filteredActiveEntries = useMemo(
    () =>
      activeEntries.filter((e) => {
        if (departmentFilter && e.employee.department !== departmentFilter) return false;
        if (statusFilter && e.status !== statusFilter) return false;
        return true;
      }),
    [activeEntries, departmentFilter, statusFilter]
  );

  const counts = useMemo(
    () =>
      activeEntries.reduce((acc, e) => {
        acc[e.status] = (acc[e.status] || 0) + 1;
        return acc;
      }, {}),
    [activeEntries]
  );

  if (loading) return <p className="text-gray-400 p-2">Loading…</p>;

  return (
    <div className="flex flex-col gap-6">
      {/* Page title + filters */}
      <div className="flex items-center gap-4 flex-wrap">
        <h2 className="text-xl font-bold text-gray-900 m-0">Dashboard</h2>
        <div className="flex items-center gap-3 ml-auto flex-wrap">
          <DepartmentFilter departments={departments} value={departmentFilter} onChange={setDepartmentFilter} />
          <StatusFilter value={statusFilter} onChange={setStatusFilter} />
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {STAT_CARDS.map(({ key, label, icon, iconBg, iconColor }) => (
          <div
            key={key}
            className="bg-white rounded-2xl p-5 shadow-sm flex items-center gap-4"
          >
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0"
              style={{ background: iconBg, color: iconColor }}
            >
              {icon}
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900 leading-none">
                {counts[key] ?? 0}
              </div>
              <div className="text-xs text-gray-400 mt-1">{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Currently active */}
      <div className="bg-white rounded-2xl shadow-sm p-6">
        <h2 className="text-base font-semibold text-gray-900 mb-4">Currently Active</h2>
        <CurrentlyActiveWidget entries={filteredActiveEntries} />
      </div>

      {/* Roster */}
      <div className="bg-white rounded-2xl shadow-sm p-6">
        <h2 className="text-base font-semibold text-gray-900 mb-4">Roster</h2>
        <RosterGrid employees={filteredEmployees} weekStart={weekStart} onWeekChange={setWeekStart} />
      </div>
    </div>
  );
}
