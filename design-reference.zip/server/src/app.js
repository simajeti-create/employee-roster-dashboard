import express from 'express';
import cors from 'cors';
import employeesRouter from './routes/employees.js';
import shiftsRouter from './routes/shifts.js';
import breaksRouter from './routes/breaks.js';
import leavesRouter from './routes/leaves.js';
import activeRouter from './routes/active.js';
import reportsRouter from './routes/reports.js';

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/employees', employeesRouter);
app.use('/api/shifts', shiftsRouter);
app.use('/api/breaks', breaksRouter);
app.use('/api/leaves', leavesRouter);
app.use('/api/active', activeRouter);
app.use('/api/reports', reportsRouter);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

export default app;
