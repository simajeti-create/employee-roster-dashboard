import db from '../db/connection.js';
import { startOfWeek, addDays, diffHours } from '../utils/dateUtils.js';
import { listLeavesForDateRange } from './leaveService.js';

export function getWeeklySummary(weekStartInput) {
  const weekStart = startOfWeek(weekStartInput || new Date().toISOString().slice(0, 10));
  const weekEnd = addDays(weekStart, 6);

  const employees = db.prepare('SELECT * FROM employees ORDER BY name').all();
  const shifts = db
    .prepare('SELECT * FROM shifts WHERE work_date BETWEEN ? AND ?')
    .all(weekStart, weekEnd);

  const shiftIds = shifts.map((s) => s.id);
  let breaksByShift = new Map();
  if (shiftIds.length > 0) {
    const placeholders = shiftIds.map(() => '?').join(',');
    const breaks = db.prepare(`SELECT * FROM breaks WHERE shift_id IN (${placeholders})`).all(...shiftIds);
    breaksByShift = breaks.reduce((map, b) => {
      if (!map.has(b.shift_id)) map.set(b.shift_id, []);
      map.get(b.shift_id).push(b);
      return map;
    }, new Map());
  }

  const leaves = listLeavesForDateRange(weekStart, weekEnd);

  const summary = employees.map((employee) => {
    const employeeShifts = shifts.filter((s) => s.employee_id === employee.id);

    let hoursWorked = 0;
    for (const shift of employeeShifts) {
      let shiftHours = diffHours(shift.start_time, shift.end_time);
      const shiftBreaks = breaksByShift.get(shift.id) || [];
      for (const b of shiftBreaks) {
        if (b.end_time) {
          shiftHours -= diffHours(b.start_time, b.end_time);
        }
      }
      hoursWorked += Math.max(0, shiftHours);
    }

    const employeeLeaves = leaves.filter((l) => l.employee_id === employee.id);
    let leaveDays = 0;
    const leaveBreakdown = {};
    for (const leave of employeeLeaves) {
      const clippedStart = leave.start_date < weekStart ? weekStart : leave.start_date;
      const clippedEnd = leave.end_date > weekEnd ? weekEnd : leave.end_date;
      const days = Math.round(
        (new Date(`${clippedEnd}T00:00:00`) - new Date(`${clippedStart}T00:00:00`)) / (1000 * 60 * 60 * 24)
      ) + 1;
      leaveDays += days;
      leaveBreakdown[leave.leave_type] = (leaveBreakdown[leave.leave_type] || 0) + days;
    }

    return {
      employee_id: employee.id,
      name: employee.name,
      department: employee.department,
      hours_worked: Math.round(hoursWorked * 100) / 100,
      leave_days: leaveDays,
      leave_breakdown: leaveBreakdown,
    };
  });

  return { week_start: weekStart, week_end: weekEnd, summary };
}

export function getNsaReport({ start, end } = {}) {
  let sql = `
    SELECT e.email, e.name, e.project_name, s.work_date
    FROM shifts s
    JOIN employees e ON e.id = s.employee_id
    WHERE e.email IS NOT NULL AND e.email != ''
      AND e.project_name IS NOT NULL AND e.project_name != ''
      AND substr(s.start_time, 12, 5) >= '17:30'
  `;
  const params = [];
  if (start) { sql += ' AND s.work_date >= ?'; params.push(start); }
  if (end)   { sql += ' AND s.work_date <= ?'; params.push(end); }
  sql += ' ORDER BY e.name, s.work_date';

  const rows = db.prepare(sql).all(...params);

  // Group by employee (email as key to handle name changes gracefully)
  const byEmployee = new Map();
  for (const row of rows) {
    const key = row.email;
    if (!byEmployee.has(key)) {
      byEmployee.set(key, { email: row.email, name: row.name, project_name: row.project_name, dates: [] });
    }
    const [y, m, d] = row.work_date.split('-');
    byEmployee.get(key).dates.push(`${m}/${d}/${y}`);
  }

  return Array.from(byEmployee.values()).map((emp) => ({
    email_id: emp.email,
    name: emp.name,
    project_name: emp.project_name,
    type_of_allowance: 'NSA',
    total_amount: emp.dates.length * 900,
    date_worked: emp.dates.join(', '),
  }));
}
